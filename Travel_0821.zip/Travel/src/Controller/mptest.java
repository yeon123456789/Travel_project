package Controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.map;
import Model.mapDAO;
import Model.memberDAO;
@WebServlet("/map2")
public class mptest extends HttpServlet {
    public mptest() {
        super();
    }
    
    

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "error.jsp";
		ArrayList<map> data = null;
		try {
			data = mapDAO.getAll2();
			if(data.size() != 0) {
				request.setCharacterEncoding("UTF-8");
				response.setContentType("text/html;charset=utf-8");
				request.setAttribute("datas", data);
				url = "jsonRes.jsp";
			}else {
				request.setAttribute("message", "��û�� �����ʹ� �����ϴ�");
				url = "msg.jsp";
			}
		} catch (SQLException e) {
			e.printStackTrace();//���� �߻� �����丮�� �����ڰ� �ܼ�â���� Ȯ��
			request.setAttribute("errorMsg", "�˼��մϴ�, �� ��û���ּ���");
		}
		
		request.getRequestDispatcher(url).forward(request, response);
		
	
	
	
	}

}
