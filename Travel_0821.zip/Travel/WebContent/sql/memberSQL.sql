CREATE table member(
	memberID varchar(20),
	memberPassword varchar(20),
	memberName varchar(20),
	memberCountry varchar(20),
	memberEmail varchar(20),
	memberGender varchar(20)
);